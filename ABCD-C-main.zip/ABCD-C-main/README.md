# ABCD-C
2025년 2학기 ABCD-C 교과목 파이썬 Coding

2025.09.16 - 처음으로  github에 코드를 올리고 commit를 해 봄
